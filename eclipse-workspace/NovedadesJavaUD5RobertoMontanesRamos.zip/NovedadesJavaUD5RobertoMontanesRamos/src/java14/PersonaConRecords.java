package java14;


public record PersonaConRecords(String nombreCompleto, int anios) { }

package java19;

public record Punto(int x, int y) {}


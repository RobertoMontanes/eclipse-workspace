package java16;

public record Persona(String nombre, int edad) {}


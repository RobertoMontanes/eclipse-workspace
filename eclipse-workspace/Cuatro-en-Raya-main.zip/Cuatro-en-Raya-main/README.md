# Cuatro-en-Raya
Este proyecto es una versión del juego de mesa Cuatro En Raya. Fue creado como proyecto académico para el grado superior de DAM que estoy cursando.
Incluye dos modos principales: 2 jugadores (persona vs persona) y 1 jugador (persona vs ordenador)

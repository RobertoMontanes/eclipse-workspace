package ejercicio2;

public class Club {

	private CRUDSocio crudSocio = new CRUDSocio();

    public CRUDSocio getCrudSocio() {
        return crudSocio;
    }
}
    
    




 
package ejercicioexamen;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		List<Trastero> listaTrasteros = new ArrayList<Trastero>();
		Oficina oficina = new Oficina(listaTrasteros);
		Scanner scanner = new Scanner(System.in);
		int opcion;

		listaTrasteros.add(new Trastero(10, "Calle 1", 1, 100, false));
		listaTrasteros.add(new Trastero(20, "Calle 2", 2, 200, true));
		listaTrasteros.add(new Trastero(30, "Calle 3", 3, 300, false));
		listaTrasteros.add(new Trastero(40, "Calle 4", 4, 400, true));

		do {
			
			System.out.println("0. Salir");
			System.out.println("1. Agregar un trastero");
			System.out.println("2. Ver todos los trasteros");
			System.out.print("\n Elige una opción: ");

			opcion = scanner.nextInt();
			scanner.nextLine();

			switch (opcion) {
				case 0:
					System.out.println("Saliendo del programa...");
					break;
	
				case 1:
				    System.out.print("Dime la capacidad en metros cuadrados: ");
				    int capacidad = scanner.nextInt();
				    scanner.nextLine(); 

				    System.out.print("Dime la dirección: ");
				    String direccion = scanner.nextLine();

				    System.out.print("Dime el número: ");
				    int numero = scanner.nextInt();

				    System.out.print("Dime el precio: ");
				    int precio = scanner.nextInt();

				    System.out.print("Dime si está ocupado (true/false): ");
				    boolean ocupado = scanner.nextBoolean();

				    listaTrasteros.add(new Trastero(capacidad, direccion, numero, precio, ocupado));
				    
				    System.out.println("Trastero agregado con éxito.");
				    break;

				case 2:
					System.out.println("\nLista de trasteros:");
					oficina.verListaTrasteros();
	
					break;
	
				default:
					System.out.println("Opción no válida. Inténtalo de nuevo.");
			}
		} while (opcion != 0);

		scanner.close();
	}
}

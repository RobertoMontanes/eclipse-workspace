package ejercicioexamen;

public class Trastero implements Comparable<Trastero> {

	private int metrosCuadrados;
	private String direccion;
	private int numero;
	private double precio;
	private boolean ocupado;

	public Trastero(int metrosCuadrados, String direccion, int numero, double precio, boolean ocupado) {
		super();
		this.metrosCuadrados = metrosCuadrados;
		this.direccion = direccion;
		this.numero = numero;
		this.precio = precio;
		this.ocupado = ocupado;
	}

	public int getMetrosCuadrados() {
		return metrosCuadrados;
	}

	public void setMetrosCuadrados(int metrosCuadrados) {
		this.metrosCuadrados = metrosCuadrados;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public boolean isOcupado() {
		return ocupado;
	}

	public void setOcupado(boolean ocupado) {
		this.ocupado = ocupado;
	}

	@Override
	public String toString() {
		return "Trastero [metrosCuadrados=" + metrosCuadrados + ", direccion=" + direccion + ", numero=" + numero
				+ ", precio=" + precio + ", ocupado=" + ocupado + "]";
	}

	@Override
	public int compareTo(Trastero t) {
		return Integer.compare(this.numero, t.numero);
	}

}

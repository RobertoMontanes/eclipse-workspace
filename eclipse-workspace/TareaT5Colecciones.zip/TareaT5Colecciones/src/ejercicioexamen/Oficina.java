package ejercicioexamen;

import java.util.ArrayList;
import java.util.List;

public class Oficina {

	List<Trastero> trasteros = new ArrayList<Trastero>();

	public Oficina(List<Trastero> trasteros) {
		super();
		this.trasteros = trasteros;
	}

	public List<Trastero> getTrasteros() {
		return trasteros;
	}

	public void setTrasteros(List<Trastero> trasteros) {
		this.trasteros = trasteros;
	}

	@Override
	public String toString() {
		return "Oficina [trasteros=" + trasteros + "]";
	}
	
	public void agregarTrastero(Trastero trastero) {
	    trasteros.add(trastero);
	}
	public void verListaTrasteros(){
		for (Trastero trastero : trasteros) {
			 System.out.println(trastero);
		}
	}
}

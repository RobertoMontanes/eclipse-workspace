package ejercicio4;

import utilidades.Leer;

public class Principal {

    public static void main(String[] args) {
        

        // Crear productos
        Producto leche = new Alimentacion(1.20, 101, "Leche", 1, true);
        Producto pan = new Alimentacion(0.80, 102, "Pan", 3, false);
        Producto smartphone = new Electronica(300.00, 201, "Smartphone", true);

        // Crear líneas de venta
        LineaVenta linea1 = new LineaVenta(leche, 3);
        LineaVenta linea2 = new LineaVenta(pan, 2);
        LineaVenta linea3 = new LineaVenta(smartphone, 1);

        // Crear venta con capacidad para 3 productos
        Venta venta = new Venta(3);

        // Variables para control del menú
        int opcion = 0;

        do {
            // Menú interactivo
            System.out.println("\n----- MENÚ DE OPCIONES -----");
            System.out.println("1. Agregar producto a la venta");
            System.out.println("2. Imprimir ticket");
            System.out.println("3. Listar productos");
            System.out.println("4. Salir");
            System.out.print("Selecciona una opción: ");
            
            // Leer la opción del usuario
            opcion = Leer.datoInt();
            // Ejecutar según la opción seleccionada
            switch (opcion) {
                case 1:
                    // Agregar producto a la venta
                    System.out.println("\nSelecciona el producto a agregar:");
                    System.out.println("1. Leche");
                    System.out.println("2. Pan");
                    System.out.println("3. Smartphone");

                    int productoSeleccionado = Leer.datoInt();
                    System.out.print("Cantidad: ");
                    int cantidad = Leer.datoInt();

                    switch (productoSeleccionado) {
                        case 1:
                            venta.agregarLineaVenta(new LineaVenta(leche, cantidad));
                            System.out.println("Producto 'Leche' agregado.");
                            break;
                        case 2:
                            venta.agregarLineaVenta(new LineaVenta(pan, cantidad));
                            System.out.println("Producto 'Pan' agregado.");
                            break;
                        case 3:
                            venta.agregarLineaVenta(new LineaVenta(smartphone, cantidad));
                            System.out.println("Producto 'Smartphone' agregado.");
                            break;
                        default:
                            System.out.println("Opción inválida.");
                    }
                    break;

                case 2:
                    // Imprimir ticket
                    venta.imprimirTicket();
                    break;

                case 3:
                    // Listar productos
                    venta.listarProductos();
                    break;

                case 4:
                    // Salir
                    System.out.println("Gracias por usar el sistema. ¡Hasta pronto!");
                    break;

                default:
                    System.out.println("Opción inválida. Intenta de nuevo.");
                    break;
            }

        } while (opcion != 4); // Se repite hasta que el usuario seleccione la opción 4 (salir)

    }
}

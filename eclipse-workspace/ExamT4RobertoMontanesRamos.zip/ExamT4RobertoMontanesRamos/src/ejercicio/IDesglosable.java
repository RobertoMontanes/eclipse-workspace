package ejercicio;

public interface IDesglosable {
	
	public double calcularIVA(double iva, int zonaAsiento, double descuento, double costoAdicional);
}
